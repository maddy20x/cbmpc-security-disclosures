# CB-MPC Core Library: buf_t::resize() / alloc() Negative Size Vulnerability

## Summary

**Vulnerability:** `buf_t::resize()` and `buf_t::alloc()` in `src/cbmpc/core/buf.cpp` 
(lines 145-203) accept negative sizes without validation, causing out-of-bounds 
memory access and undefined behavior.

**Severity:** HIGH (CVSS 7.5)

**Bounty:** Up to $15,000 (Coinbase Bug Bounty Program)

## The Bug

```cpp
// LINE 182: resize() has NO check for new_size >= 0
byte_t* resize(int new_size) {
    if (s == new_size) return data();
    // ... calls helper with negative new_size
}

// LINE 194: alloc() has NO check for new_size >= 0
byte_t* alloc(int new_size) {
    if (s == new_size) return data();
    free();
    s = new_size;  // negative!
    // ...
}
```

The constructor has `cb_assert(new_size >= 0)` but `resize()` and `alloc()` 
don't. This inconsistency allows negative sizes to bypass validation.

## PoC Results (Real Library)

```
--- Test 1: resize(16) then resize(-1) ---
  After:  size=-1 ← NEGATIVE! ✅

--- Test 2: alloc(-100) ---
  After alloc(-100): size=-100 ← NEGATIVE! ✅

--- Test 3: alloc(64) then resize(-2000) ---
  Calling resize(-2000) on REAL buf_t...
  🔴 CRASH (memmove reads ~4GB from heap)
```

## Build Instructions

```bash
# 1. Clone cb-mpc
git clone https://github.com/coinbase/cb-mpc.git
cd cb-mpc

# 2. Build the library
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTS=OFF
make -j2 cbmpc

# 3. Build and run the PoC
cd ..
g++ -std=c++17 -Iinclude -Iinclude-internal \
    -o poc_real poc_real.cpp lib/Release/libcbmpc.a \
    -lpthread -lcrypto -lsodium

./poc_real
```

## Impact

| Scenario | Effect |
|----------|--------|
| `resize(-1)` on short buf | `secure_bzero(m - 1, 17)` → writes before buffer |
| `resize(-2000)` on long buf | `memmove(stack, heap, -2000)` → 4GB heap read → crash |
| `alloc(-100)` | `s = -100` → all subsequent operations use negative size |
| `new byte_t[-1]` | Undefined behavior (bad_alloc or undersized allocation) |

## Files

- `poc_real.cpp` - Proof of Concept (links against real libcbmpc.a)
- `vulnerability_report.md` - Full report for Coinbase submission

## Affected Code

**File:** `src/cbmpc/core/buf.cpp`  
**Lines:** 145-203  
**Functions:** `buf_t::resize()`, `buf_t::alloc()`, `resize_save_*`

## Disclosure

Responsible disclosure to Coinbase via bug bounty program.
